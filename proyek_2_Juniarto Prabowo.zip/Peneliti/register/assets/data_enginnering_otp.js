// Tampilkan email pengguna di halaman OTP
document.addEventListener("DOMContentLoaded", function() {
    let email = localStorage.getItem("userEmail");
    document.getElementById("userEmail").textContent = email || "Email tidak ditemukan!";
});

// Memindahkan input ke kolom berikutnya secara otomatis
document.querySelectorAll(".otp-field").forEach((input, index, inputs) => {
    input.addEventListener("input", (e) => {
        if (e.target.value.length === 1 && index < inputs.length - 1) {
            inputs[index + 1].focus();
        }
    });
});

// Simpan OTP dan arahkan ke halaman selamat datang
document.getElementById("otpForm").addEventListener("submit", function(event) {
    event.preventDefault();
    window.location.href = "data_engineer_welcome.html"; // Redirect ke halaman selamat datang
});
