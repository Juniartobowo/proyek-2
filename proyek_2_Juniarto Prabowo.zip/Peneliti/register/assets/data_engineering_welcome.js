document.addEventListener("DOMContentLoaded", function() {
    let email = localStorage.getItem("userEmail");
    document.getElementById("userEmail").textContent = email || "Pengguna Baru";
});

function goToHome() {
    localStorage.removeItem("userEmail"); // Hapus email setelah login
    window.location.href = "C:/Users/ocanh/Downloads/Peneliti/Data Engineer/Dashboard.html"; // Ganti dengan halaman selanjutnya
}
