document.getElementById("registerForm").addEventListener("submit", function(event) {
    event.preventDefault();
    let email = document.getElementById("email").value;
    localStorage.setItem("userEmail", email); // Simpan email user
    window.location.href = "manajemen_proyek_otp.html"; // Redirect ke halaman OTP
});
