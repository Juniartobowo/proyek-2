document.addEventListener("DOMContentLoaded", function () {
    // Fungsi untuk navigasi sidebar tanpa reload
    const sidebarLinks = document.querySelectorAll(".sidebar a");

    sidebarLinks.forEach(link => {
        link.addEventListener("click", function (e) {
            e.preventDefault();
            const targetPage = this.getAttribute("href");
            if (targetPage && targetPage !== "#") {
                window.location.href = targetPage;
            }
        });
    });

    // Fungsi progress bar untuk unggah dataset
    const uploadButton = document.getElementById("upload-button");
    const progressBar = document.getElementById("progress-bar");

    if (uploadButton && progressBar) {
        uploadButton.addEventListener("click", function () {
            let progress = 0;
            progressBar.style.width = "0%";
            progressBar.style.backgroundColor = "blue";
            progressBar.style.height = "20px";
            progressBar.style.transition = "width 2s";

            const interval = setInterval(() => {
                progress += 20;
                progressBar.style.width = progress + "%";

                if (progress >= 100) {
                    clearInterval(interval);
                    alert("✅ Dataset berhasil diunggah!");
                }
            }, 500);
        });
    }

    // Fungsi untuk unduh laporan validasi
    const downloadReportButton = document.getElementById("download-report");
    if (downloadReportButton) {
        downloadReportButton.addEventListener("click", function () {
            alert("📂 Laporan validasi telah diunduh!");
        });
    }

    // Grafik Doughnut Chart.js untuk validasi dataset
    const validationChartCanvas = document.getElementById("validationChart");

    if (validationChartCanvas && typeof Chart !== "undefined") {
        const ctx = validationChartCanvas.getContext("2d");
        new Chart(ctx, {
            type: "doughnut",
            data: {
                labels: ["Valid", "Invalid"],
                datasets: [{
                    data: [85, 35],
                    backgroundColor: ["#4CAF50", "#FF5733"] // Warna lebih soft
                }]
            },
            options: {
                cutout: "70%", // Ukuran lebih kecil
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: "bottom"
                    }
                }
            }
        });
    }
});
