document.addEventListener("DOMContentLoaded", function() {
    let datasets = [
        { name: "Dataset Karyawan", description: "Data kehadiran & performa karyawan", size: "5MB", link: "datasets/karyawan.csv" },
        { name: "Dataset Penjualan", description: "Data transaksi penjualan e-commerce", size: "10MB", link: "datasets/penjualan.csv" },
        { name: "Dataset Cuaca", description: "Data suhu dan cuaca harian", size: "7MB", link: "datasets/cuaca.csv" }
    ];

    let tableBody = document.getElementById("dataset-list");

    datasets.forEach(dataset => {
        let row = document.createElement("tr");
        row.innerHTML = `
            <td>${dataset.name}</td>
            <td>${dataset.description}</td>
            <td>${dataset.size}</td>
            <td><button class="download" onclick="downloadDataset('${dataset.link}')">Download</button></td>
        `;
        tableBody.appendChild(row);
    });
});

function downloadDataset(link) {
    window.location.href = link;
}
