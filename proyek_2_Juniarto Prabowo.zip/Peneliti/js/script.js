document.addEventListener("DOMContentLoaded", function () {
    // Tambah baris stakeholder
    document.getElementById("tambah-stakeholder").addEventListener("click", function () {
        let table = document.getElementById("stakeholder-table").getElementsByTagName("tbody")[0];
        let newRow = table.insertRow();
        
        for (let i = 0; i < 3; i++) {
            let cell = newRow.insertCell(i);
            let input = document.createElement("input");
            input.type = "text";
            input.placeholder = i === 0 ? "Nama" : i === 1 ? "Peran" : "Kepentingan";
            cell.appendChild(input);
        }
    });

    // Simpan Data
    document.getElementById("simpan").addEventListener("click", function () {
        let deskripsi = document.getElementById("deskripsi-masalah").value;
        let tujuan = document.getElementById("tujuan-model").value;
        let inputData = document.getElementById("input-data").value;
        let prosesData = document.getElementById("proses-data").value;
        let outputData = document.getElementById("output-data").value;
        let kriteria = document.getElementById("kriteria-keberhasilan").value;

        let stakeholderRows = document.querySelectorAll("#stakeholder-table tbody tr");
        let stakeholders = [];
        stakeholderRows.forEach(row => {
            let inputs = row.getElementsByTagName("input");
            stakeholders.push({
                nama: inputs[0].value,
                peran: inputs[1].value,
                kepentingan: inputs[2].value
            });
        });

        let data = {
            deskripsi,
            tujuan,
            ipo: { inputData, prosesData, outputData },
            kriteria,
            stakeholders
        };

        console.log("Data disimpan:", data);
        alert("Data berhasil disimpan!");
    });

    // Review Data
    document.getElementById("review").addEventListener("click", function () {
        alert("Review data sebelum dikirim!");
    });
});
